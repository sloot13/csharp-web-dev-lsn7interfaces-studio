﻿using System;
namespace SpinningDiscs
{
    public interface IOpticalDisc
    {
        void SpinDisc();
        void ReadData();
    }
}
